# Clear Module
## Made and Updated by: Jordan Dixon

Find me on [repl.it](https://repl.it/@JordanDixon1)

This module clears the terminal for any os. This module can be very helpful when making text-based games, console commands, etc. The syntax is as follows:
```python3
import clearing
clearing.clear()
```